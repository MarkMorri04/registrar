<?php 
$host="localhost";
$dbname='user_system';
$username='root';
$password='';

$pdo=new PDO("mysql:host=$host;dbname=$dbname",$username,$password);
