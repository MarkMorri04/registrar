<?php
    $conn = mysqli_connect('localhost','root','','request');

    if(!$conn) {
        die("mali ka morri");
    }
?>